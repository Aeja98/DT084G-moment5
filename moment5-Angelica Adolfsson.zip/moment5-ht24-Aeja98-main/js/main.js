// Denna fil ska innehålla din lösning till uppgiften (moment 5).

"use strict";

/*  Delar till ej obligatorisk funktionalitet, som kan ge poäng för högre betyg
*   Radera rader för funktioner du vill visa på webbsidan. */
document.getElementById("player").style.display = "none";      // Radera denna rad för att visa musikspelare
document.getElementById("shownumrows").style.display = "none"; // Radera denna rad för att visa antal träffar

/* Här under börjar du skriva din JavaScript-kod */

//Start av applikation
window.onload = init;

function init() {
    getChannelInfo();
}

//Hämta data från webbtjänst
function getChannelInfo() {
    const url = "https://api.sr.se/api/v2/channels?format=json";
    
    //Anropa webbtjänst
    fetch(url)
    .then(Response => Response.json())
    .then(data => channelList(data.channels))
    .catch(error => console.log(error))
}

//nav list for channels
function channelList (channels) {
    const mainnavlistEl = document.getElementById("mainnavlist");

    //go through & write down each channel name
    channels.forEach(channels => {

        let newListEl = document.createElement("ul");
        let newChannelText = document.createTextNode(channels.name);
        newListEl.appendChild(newChannelText);

        mainnavlistEl.appendChild(newListEl);
    }
    )
}

//mouse over info
channelList.addEventListener("mouseover", channelTagLine);


//click on text to open schedule stuff
channelList.addEventListener("click", displayChannelInfo);


//Mouse over something on the list to show short description
function channelTagLine() {


}

//Which channel we are clicking on
let channelid = 

//Ta emot & skriv ut kanalinfo
function displayChannelInfo(schedule) {

    let channelurl = "https://api.sr.se/api/v2/scheduledepisodes?"+channelid+"&format=json";
    fetch(channelurl)
    .then(Response => Response.json())
    .then(data => displayChannelInfo(data.channels))
    .catch(error => console.log(error))


    const infoEl = document.getElementById("info");


    //Loopar igenom & skriver ut
    schedule.forEach(schedule => {
        let newArticleEl =document.createElement("article");

        //Överskrift => channel Name
        let newTitleEl = document.createElement("h2");
        let newTitleText = document.createTextNode(schedule.title);
        newTitleEl.appendChild(newTitleText);

        //Start of program
        let newChannelStartEl = document.createElement("h4");
        let newChannelStartText = document.createTextNode(schedule.starttimeutc);
        newChannelStartEl.appendChild(newChannelStartText);

        //End of program
        let newChannelEndEl = document.createElement("h4");
        let newChannelEndText = document.createTextNode(schedule.endtimeutc);
        newChannelEndEl.appendChild(newChannelEndText);

        //Program description
        let newDescriptionEl = document.createElement("p");
        let newDescriptionText = document.createTextNode(schedule.description);
        newDescriptionEl.appendChild(newDescriptionText);

        //Slå ihop
        newArticleEl.appendChild(newTitleEl);
        newArticleEl.appendChild(newChannelStartEl);
        newArticleEl.appendChild(newChannelEndEl);
        newArticleEl.appendChild(newDescriptionEl);

        infoEl.appendChild(newArticleEl);
    }
    )
}


